(()=>{
const D=document,B=D.body,still=matchMedia('(prefers-reduced-motion: reduce)').matches;
D.documentElement.classList.add('js');

/* soft page fade */
requestAnimationFrame(()=>requestAnimationFrame(()=>B.classList.add('shown')));
addEventListener('pageshow',e=>{if(e.persisted){B.classList.remove('leaving');B.classList.add('shown')}});
D.addEventListener('click',e=>{const a=e.target.closest('a[href]');if(!a||e.defaultPrevented||e.metaKey||e.ctrlKey||e.shiftKey||a.target)return;
 const h=a.getAttribute('href');if(!h||!/^[a-z-]+\.html(#.*)?$/.test(h)||still)return;
 e.preventDefault();B.classList.remove('menu-open');B.classList.add('leaving');setTimeout(()=>{location.href=h},480);setTimeout(()=>B.classList.remove('leaving'),2500)});

/* header */
const hero=D.querySelector('.hero');
const onScroll=()=>{const h=hero&&hero.offsetParent!==null?hero:null;const lim=h?h.offsetHeight-90:30;B.classList.toggle('scrolled',scrollY>lim)};
addEventListener('scroll',onScroll,{passive:true});addEventListener('resize',onScroll);

/* single-file preview: pages as views, routed on the hash */
const views=[...D.querySelectorAll('.view')];
if(views.length){const route=()=>{let id=(location.hash||'#home').slice(1);if(!D.getElementById('v-'+id))id='home';
  views.forEach(v=>v.hidden=v.id!=='v-'+id);B.classList.toggle('home',id==='home');B.classList.toggle('inner',id!=='home');
  D.querySelectorAll('.hdr nav a,.mlist a').forEach(a=>{if(a.getAttribute('href')==='#'+id)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});
  B.classList.remove('menu-open');const mb0=D.getElementById('mbtn');if(mb0){mb0.textContent='Menu';mb0.setAttribute('aria-expanded',false)}
  scrollTo(0,0);onScroll();requestAnimationFrame(()=>dispatchEvent(new Event('scroll')))};
 addEventListener('hashchange',route);route()}
onScroll();

/* hero slideshow */
if(hero){const S=[...hero.querySelectorAll('.slides img')],dots=[...hero.querySelectorAll('.dots i')];let i=0;
 const show=k=>{S.forEach((s,j)=>s.classList.toggle('on',j===k));dots.forEach((d,j)=>{d.classList.remove('on');if(j===k){void d.offsetWidth;d.classList.add('on')}})};
 show(0);if(!still&&S.length>1)setInterval(()=>{i=(i+1)%S.length;show(i)},6000)}

/* menu */
const mb=D.getElementById('mbtn'),menu=D.getElementById('menu');
if(mb&&menu){const set=o=>{B.classList.toggle('menu-open',o);mb.setAttribute('aria-expanded',o);mb.textContent=o?'Close':'Menu';if(o)setTimeout(()=>menu.querySelector('a')?.focus(),300)};
 mb.onclick=()=>set(!B.classList.contains('menu-open'));
 D.addEventListener('keydown',e=>{if(e.key==='Escape'&&B.classList.contains('menu-open'))set(false)});
 const pics=[...menu.querySelectorAll('.mpic img')];
 menu.querySelectorAll('.mlist a').forEach((a,k)=>{const sh=()=>pics.forEach((p,j)=>p.classList.toggle('on',j===k));a.addEventListener('mouseenter',sh);a.addEventListener('focus',sh)});
 pics[0]?.classList.add('on')}

/* principles: hover or scroll picks the picture */
const pl=[...D.querySelectorAll('.plist li')],pi=[...D.querySelectorAll('.pimg img')];
if(pl.length){const pick=k=>{pl.forEach((l,j)=>l.classList.toggle('on',j===k));pi.forEach((p,j)=>p.classList.toggle('on',j===k))};
 pick(0);pl.forEach((l,k)=>{l.addEventListener('mouseenter',()=>pick(k));l.addEventListener('focus',()=>pick(k));l.addEventListener('click',()=>pick(k))});
 if(!still&&matchMedia('(hover: none)').matches){let k=0;setInterval(()=>{k=(k+1)%pl.length;pick(k)},3500)}}

/* principle panels */
const pn=[...D.querySelectorAll('.pnl')];
if(pn.length){const op=k=>pn.forEach((p,j)=>p.classList.toggle('on',j===k));
 pn.forEach((p,k)=>{p.addEventListener('mouseenter',()=>op(k));p.addEventListener('focus',()=>op(k));p.addEventListener('click',()=>op(k))})}

/* local times */
const fmt=tz=>{try{return new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit',timeZone:tz}).format(new Date())}catch(_){return ''}};
const clocks=()=>D.querySelectorAll('[data-tz]').forEach(el=>el.textContent=fmt(el.dataset.tz));clocks();setInterval(clocks,30000);

/* reveals */
const rv=[...D.querySelectorAll('.rv,.ri')];
if(still||!('IntersectionObserver' in window))rv.forEach(e=>e.classList.add('vis'));
else{const o=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){const el=e.target;setTimeout(()=>el.classList.add('vis'),+(el.dataset.d||0));o.unobserve(el)}}),{threshold:.1,rootMargin:'0px 0px -5% 0px'});
 rv.forEach(e=>o.observe(e));setTimeout(()=>rv.forEach(e=>{if(e.offsetParent!==null&&e.getBoundingClientRect().top<innerHeight)e.classList.add('vis')}),80)}

/* the day + parallax */
const day=D.getElementById('day');let P=[],M=[],T=[];
if(day){P=[...day.querySelectorAll('.scene img')];M=[...day.querySelectorAll('.moment')];T=[...day.querySelectorAll('.clock li')]}
const px=[...D.querySelectorAll('.bleed img,.finale img')];
function tick(){
 if(day){const r=day.getBoundingClientRect(),span=r.height-innerHeight,p=Math.min(1,Math.max(0,-r.top/span)),f=p*(P.length-1);
  P.forEach((im,i)=>{im.style.opacity=i==0?1:Math.min(1,Math.max(0,(f-(i-.72))*2.2));if(!still)im.style.transform='translateY('+(-p*5).toFixed(2)+'%)'});
  M.forEach((m,i)=>m.style.opacity=Math.min(1,Math.max(0,1-(Math.abs(f-i)-.22)*3.6)));
  const c=Math.round(f);T.forEach((d,i)=>d.classList.toggle('on',i===c))}
 if(!still)px.forEach(im=>{const r=im.parentElement.getBoundingClientRect();if(r.bottom<0||r.top>innerHeight)return;im.style.transform='translateY('+(-(r.top+r.height/2-innerHeight/2)/innerHeight*5).toFixed(2)+'%)'});
}
addEventListener('scroll',()=>requestAnimationFrame(tick),{passive:true});addEventListener('resize',tick);tick();

/* rails */
D.querySelectorAll('.rail').forEach(r=>{const t=r.querySelector('.track');if(!t)return;
 r.querySelectorAll('.ctl button').forEach(b=>b.onclick=()=>t.scrollBy({left:(+b.dataset.dir)*t.clientWidth*.7,behavior:still?'auto':'smooth'}));
 let x0=0,s0=0,dn=false;t.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse')return;dn=true;x0=e.clientX;s0=t.scrollLeft;t.classList.add('drag')});
 addEventListener('pointermove',e=>{if(dn)t.scrollLeft=s0-(e.clientX-x0)});addEventListener('pointerup',()=>{if(dn){dn=false;t.classList.remove('drag')}})});

/* enquiry panel */
const panel=D.getElementById('panel'),card=D.getElementById('card');
if(panel){const modes={intro:['Enquiry','New project enquiry.','Tell us about the site, the brief and your timescale.','Thank you. We will be in touch to arrange a first meeting.'],
  folio:['Portfolio request','Request our portfolio.','Tell us a little about you and your project, and we will send a selection of our work.','Thank you. We will send a selection of our work.'],
  introduction:['Meeting request','Arrange a meeting.','Tell us who you are and what you are planning.','Thank you. We will be in touch to arrange a meeting.']};
 const open=m=>{card.classList.remove('pv','sent');const v=modes[m]||modes.intro;D.getElementById('req').value=v[0];D.getElementById('ph').textContent=v[1];D.getElementById('pp').textContent=v[2];D.getElementById('tp').textContent=v[3];B.classList.remove('menu-open');panel.classList.add('open');setTimeout(()=>D.getElementById('n').focus(),300)};
 D.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>open(b.dataset.mode)));
 D.querySelectorAll('[data-privacy]').forEach(b=>b.addEventListener('click',()=>{card.classList.remove('sent');card.classList.add('pv');panel.classList.add('open')}));
 panel.addEventListener('click',e=>{if(e.target===panel||e.target.hasAttribute('data-close'))panel.classList.remove('open')});
 D.addEventListener('keydown',e=>{if(e.key==='Escape')panel.classList.remove('open')})}
const send=async(f,ok)=>{try{const r=await fetch('/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(f)).toString()});if(!r.ok)throw 0;ok();f.reset()}
 catch(_){let m=f.querySelector('.err');if(!m){m=D.createElement('p');m.className='err';f.appendChild(m)}m.textContent='That did not send. Please email info@barearchitecture.com instead.'}};
const pf=D.getElementById('f');if(pf)pf.addEventListener('submit',e=>{e.preventDefault();send(pf,()=>card.classList.add('sent'))});
const cf=D.getElementById('cf');if(cf)cf.addEventListener('submit',e=>{e.preventDefault();send(cf,()=>{cf.classList.add('sent');cf.scrollIntoView({block:'center'})})});
D.querySelectorAll('[data-copy]').forEach(b=>b.addEventListener('click',()=>{const t=b.dataset.copy;if(navigator.clipboard)navigator.clipboard.writeText(t).then(()=>{const o=b.textContent;b.textContent='Copied';setTimeout(()=>b.textContent=o,1600)},()=>{})}));
})();
